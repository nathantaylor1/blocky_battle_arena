﻿public enum Items
{
    PickaxePowerUp,
    SwordPowerUp,
    Coin
}