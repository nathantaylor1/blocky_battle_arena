using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DataCarryOver : MonoBehaviour
{
    public static string GameSeed = "Random";
    
    public static bool StillAlive = false;
    public static int PlayerHP = 10;
    public static int PlayerScore = 0;
    public static int NumberOfBreakableBlocks = 0;
}
